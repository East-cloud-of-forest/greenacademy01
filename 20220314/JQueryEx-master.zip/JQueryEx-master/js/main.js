$(function(){

	// 슬릭 추가 및 속성 변경
	/* 직접 작성할 공간 */



	// 탭 메뉴 숨기기 및 활성화
	$("#notice_tab_wrap h4 a").on("click", tabmenu);
	function tabmenu(e) {
		/* 직접 작성할 공간 */
		e.preventDefault();

	}

});